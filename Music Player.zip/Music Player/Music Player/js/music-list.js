let allMusic = [
  {
    name: "Faded",
    artist: "Alan walker",
    img: "music-1",
    src: "music-1"
  },
  {
    name: "Falling down",
    artist: "Lil Peep , XXXTentacion",
    img: "music-2",
    src: "music-2"
  },
  {
    name: "Rather - be",
    artist: "Clean Bandit",
    img: "music-3",
    src: "music-3"
  },
  {
    name: "stay",
    artist: "The Kid LAROI , Justin Bieber",
    img: "music-4",
    src: "music-4"
  },
];